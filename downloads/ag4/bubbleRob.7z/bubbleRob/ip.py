import sys
import requests
import socket

# 獲取主機名
hostname = socket.gethostname()

# 獲取主機的 IPv4 IP 地址
ip_address = socket.gethostbyname(hostname)
# 使用API來獲取你的IP地址
#response = requests.get('https://api.ipify.org')
#ip_address = response.text

# 將IP地址存儲到一個變數中
my_ip = ip_address
ip = '0'
try:
    with open('my_ip.txt', 'r') as f:
        my_ip1 = f.readlines()
        for line in my_ip1:
            if 'game' in line: #game #myip #local
                ip = line.split(':')[1].strip()
        
except: 
    pass
# 從命令行参數中获取gameip
gameip = ip if len(sys.argv) < 2 else sys.argv[1]

# 將IP地址寫入一個文本檔案中
with open('my_ip.txt', 'w') as f:
    f.write('myip: ' + my_ip + '\n')
    f.write('local: 127.0.0.1\n')
    f.write('game: ' + gameip + '\n')

# 打印成功儲存訊息
print("本機的 IPv4 IP 地址是:",ip_address)
print('IP地址已成功儲存到my_ip.txt')

