import sim
import sys, math
import keyboard
import time

with open('my_ip.txt', 'r') as f:
    my_ip1 = f.readlines()
    for line in my_ip1:
        if 'game' in line: #game #myip #local
            ip = line.split(':')[1].strip()
            print(ip)

# 連接到 CoppeliaSim simulation
sim.simxFinish(-1)
clientID = sim.simxStart(ip, 19997, True, True, 5000, 5)
sim.simxStartSimulation(clientID, sim.simx_opmode_oneshot_wait)

if clientID != -1:
    print("已連線到遠端 CoppeliaSim 伺服器")
else:
    print('連線失敗')
    sys.exit('無法連線到 CoppeliaSim 伺服器')

# 取得馬達與感測器的 handles
errorCode, leftMotor = sim.simxGetObjectHandle(clientID, 'leftMotor', sim.simx_opmode_oneshot_wait)
errorCode, rightMotor = sim.simxGetObjectHandle(clientID, 'rightMotor', sim.simx_opmode_oneshot_wait)
errorCode, sensingNose = sim.simxGetObjectHandle(clientID, 'sensingNose', sim.simx_opmode_oneshot_wait)

# 設定一些參數
deg = math.pi/180
paused = False
if errorCode == -1:
    print('找不到左右馬達')
    sys.exit()

def jointspeed(left,right):
    errorCode4=sim.simxSetJointTargetVelocity(clientID,leftMotor,left, sim.simx_opmode_oneshot)
    errorCode5=sim.simxSetJointTargetVelocity(clientID,rightMotor,right, sim.simx_opmode_oneshot_wait)
errorCode, number2 = sim.simxLoadModel(clientID, 'number2.ttm', 0, sim.simx_opmode_oneshot_wait)   
while sim.simxGetConnectionId(clientID) != -1:
    event = keyboard.read_event()
    if event.event_type == 'down':
        print('The "' + event.name + '" key was pressed.')
    if event.name == 'a' :
        jointspeed(-3,5)
    elif event.name == 'w' :
        jointspeed(5,5)
    elif event.name == 's' :
        jointspeed(-5,-5)
    elif event.name == 'd' :
        jointspeed(5,-3)
    if event.name == 'p':
        if not paused:
            print('Paused')
            sim.simxPauseSimulation(clientID, sim.simx_opmode_oneshot_wait)
            paused = True
            time.sleep(0.1)
        else:
            print('Resumed')
            sim.simxStartSimulation(clientID, sim.simx_opmode_oneshot_wait)
            paused = False
            time.sleep(0.1)
